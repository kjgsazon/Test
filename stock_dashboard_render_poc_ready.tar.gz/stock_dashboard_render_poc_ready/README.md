# stock-dashboard-realtime-poc (Render-ready)

不靠 TradingView / 不靠券商 API 的 Realtime PoC：
- 1 秒更新
- 5 分 K 聚合（in-progress + close）

## 本機
```bash
npm install
npm run start
```
打開 http://localhost:3000

## Render
Push 到 GitHub → Render New Web Service → 選 repo → Done
